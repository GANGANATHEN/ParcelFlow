"use client";
import { useState, useRef, useEffect, useLayoutEffect } from "react";
import { ChevronRight } from "lucide-react";
// import {
//   Accordion,
//   AccordionContent,
//   AccordionItem,
//   AccordionTrigger,
// } from "@/components/ui/accordion";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { DrawSVGPlugin } from "gsap/DrawSVGPlugin";
import { MotionPathPlugin } from "gsap/MotionPathPlugin";
import { MorphSVGPlugin } from "gsap/dist/MorphSVGPlugin";
import { useGSAP } from "@gsap/react";
import { GSDevTools } from "gsap/GSDevTools"; // Import the plugin
import useLineAnimation from "@/hooks/useLineAnimation";
import {
  buttonShape,
  childline,
  diamondShape,
  smallButtonShape,
  starShape,
  wings,
  heartShape,
  squareShape,
  shieldShape,
  impellerShape,
  bShape,
  arrowShape,
  mShape,
} from "./pathData";

if (typeof window !== "undefined") {
  gsap.registerPlugin(
    ScrollTrigger,
    DrawSVGPlugin,
    MotionPathPlugin,
    MorphSVGPlugin,
    GSDevTools,
  );
}

const invadersData = [
  {
    id: 0,
    content:
      "Up to 50% cashback | Level up by making exchanges and completing tasks",
  },
  {
    id: 1,
    content:
      "Customizable NFTs | Find your invader's unique style using scenes, skins and exclusive accessories from the store",
  },
  {
    id: 2,
    content:
      "Personal Account | Track your exchange history, request payments any time. Support 24/7",
  },
];

const levels = [
  { id: 0, label: "1 LEVEL" },
  { id: 1, label: "2 LEVEL" },
  { id: 2, label: "3 LEVEL" },
  { id: 3, label: "4 LEVEL" },
  { id: 4, label: "5 LEVEL" },
  { id: 5, label: "6 LEVEL" },
];

const costData = [
  { id: 0, cost: 100 },
  { id: 1, cost: 500 },
  { id: 2, cost: 1000 },
  { id: 3, cost: 5000 },
  { id: 4, cost: 10000 },
  { id: 5, cost: 30000 },
];

const CaseBackData = [
  { id: 0, caseback: "15%" },
  { id: 1, caseback: "20%" },
  { id: 2, caseback: "25%" },
  { id: 3, caseback: "30%" },
  { id: 4, caseback: "40%" },
  { id: 5, caseback: "50%" },
];

const InvadersClub = () => {
  const [ApplyStyle, setApplyStyle] = useState(false);
  const [ContentId, setContentId] = useState(0);

  // draw line-animation ref
  const refs = useRef({
    buttons: [],
    btnWraps: [],
    bg: [],
  });

  const smallSectionRef = useRef(null);
  const smallRef1 = useRef(null);
  const smallRef2 = useRef(null);
  const smallRef3 = useRef(null);
  const revealSection = useRef(null);

  // draw-line-animation funtionality using gsap

  const faqData = [
    {
      id: "item-1",
      question: "Is there a way to predict Bitcoin future price?",
      answer:
        "Cryptocurrency prices are famously volatile, so trying to forecast them is a very daunting task. However, if you like to read what the experts have to say about the future of crypto, you may find this page interesting:",
      linkText: "BTC price prediction",
    },
    {
      id: "item-2",
      question: "How does Bitcoin mining work?",
      answer:
        "Bitcoin mining is the process by which new bitcoins are entered into circulation. It is also the way the network confirms new transactions and is a critical component of the blockchain.",
      linkText: "Learn about mining",
    },
    {
      id: "item-3",
      question: "Is Bitcoin legal?",
      answer:
        "The legality of Bitcoin depends on your country. Some nations allow its use, while others have restricted or banned it. Always check local regulations before investing.",
      linkText: "View legal map",
    },
    {
      id: "item-4",
      question: "What is a crypto wallet?",
      answer:
        "A crypto wallet is a device or application that stores your private keys and allows you to access your digital assets on the blockchain.",
      linkText: "Wallet guide",
    },
  ];

  //smallest length draw-line animation
  useGSAP(
    () => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: smallSectionRef.current,
          start: "top top",
          end: "bottom center",
          scrub: 0.5,
          fastScrollEnd: true,
        },
      });

      tl.fromTo(
        smallRef1.current,
        {
          drawSVG: "0% 0%",
        },
        {
          drawSVG: "0% 100%",
          ease: "linear",
          duration: 1,
        },
        0,
      );

      tl.fromTo(
        smallRef2.current,
        {
          drawSVG: "0% 0%",
        },
        {
          drawSVG: "0% 100%",
          ease: "linear",
          duration: 1,
        },
        0,
      );

      tl.fromTo(
        smallRef3.current,
        { drawSVG: "0% 0%" },
        {
          drawSVG: "-100% 0%",
          ease: "linear",
          duration: 1,
        },
        0,
      );
    },
    { scope: smallSectionRef },
  );

  // large line animation -------------------------------------------

  // useLayoutEffect(() => {
  //   const section = refs.current.scope;
  //   const svg = refs.current.svg;

  //   if (!section || !svg) return;

  //   const observer = new ResizeObserver(() => {
  //     svg.setAttribute("height", section.offsetHeight);
  //   });

  //   observer.observe(section);

  //   return () => observer.disconnect();
  // }, [refs]);

  const strokeData = {
    strokeWidth: 3,
    strokeColor: "#D3ED05",
  };

  useLineAnimation({ refs });

  // line animation -------------------------------------------

  useEffect(() => {
    gsap.to(".img-3", { rotate: -360, duration: 10, ease: "linear" });
  }, []);

  const handleMouseStyle = (id) => {
    setContentId(id);
    setApplyStyle(true);
  };

  const handleStyleLeave = () => {
    setApplyStyle(false);
  };

  return (
    <section className="w-full  3xl:px-60! relative z-10 max-[425px]:px-4 max-md:pb-[30px]! min-[425px]:px-5 min-[500px]:px-6 md:pb-10 sm:px-7 md:px-9 lg:px-12 xl:px-16 2xl:px-35  h-auto  2xl:pt-33! max-sm:pt-16 sm:pt-20 lg:pt-25 ">
      <p className="flex items-center gap-1.5 text-[#e6e6e6] font-archivo font-normal">
        Main <ChevronRight style={{ width: "18px" }} /> Invaders Club
      </p>

      {/* section-1  */}
      <section
        ref={smallSectionRef}
        className="w-full grid md:grid-cols-2 grid-cols-1 lg:gap-12 gap-7 pt-[30px] pb-[50px] "
      >
        <div className="w-full">
          <h1 className="text-white lg:text-[42px] md:text-[32px] text-[28px] font-normal mb-2 font-gothic">
            Welcome to SwapSpace Invaders Club!
          </h1>
          <p className="text-[#E6E6E6] font-archivo mb-5">
            SwapSpace offers an enticing loyalty program based on NFTs: using
            Invader NFT during exchanges, you can easily receive cashback up to
            50% of the RevShare
          </p>

          <div className="flex flex-col gap-3.5 xs:gap-5">
            {invadersData.map((item) => (
              <p
                onMouseEnter={() => handleMouseStyle(item.id)}
                onMouseLeave={handleStyleLeave}
                key={item.id}
                className={`${
                  ContentId === item.id && ApplyStyle === true
                    ? "border-[#C1C1C1] "
                    : "border-[#1c1c1c]"
                }  transition-all duration-300 linear font-archivo text-white text-base bg-[#1C1C1C] border rounded-[14px] py-3 px-5 md:py-4 md:px-7`}
              >
                {item.content}
              </p>
            ))}
          </div>

          {/* supScript content with draw-line animation */}

          <div className="flex flex-col gap-5 md:gap-8">
            <div className="flex gap-[140px] mt-12">
              {["Stage 1", "Stage 2", "Stage 3"].map((items, index) => (
                <p
                  key={index}
                  className="text-3xl font-medium text-white font-archivo"
                >
                  {items}
                </p>
              ))}
            </div>

            <div>
              <div className="flex gap-53">
                <p className="font-archivo font-normal text-white text-xl">
                  Genesis NFT airdrop <sup>1</sup>
                </p>

                <p className="font-archivo font-normal text-white text-xl">
                  Metaverse of loyalty <sup>3</sup>
                </p>
              </div>

              <div className="flex ml-19 items-center">
                <p>
                  <svg
                    id="small-1"
                    width="92"
                    height="45"
                    viewBox="0 0 92 45"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      ref={smallRef1}
                      d="M40.0326 0.292969C62.0326 30.793 47.0326 47.293 29.5326 43.293C12.0326 39.293 -22.9674 17.793 24.0326 14.793C61.6326 12.393 84.0317 23.4596 90.5312 29.293M90.5312 29.293L85.0312 14.793M90.5312 29.293L76.5312 32.293"
                      stroke="#D3ED05"
                      strokeWidth="2.5"
                    />
                  </svg>
                </p>
                <p className="font-archivo font-normal text-white text-xl">
                  Reveal & customize <sup>2</sup>
                </p>

                <p>
                  <svg
                    id="small-2"
                    width="105"
                    height="46"
                    viewBox="0 0 105 46"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      ref={smallRef2}
                      d="M0.0742188 35.6509C42.4742 42.0509 46.4076 19.9843 43.0742 8.15093C38.7409 4.15093 27.9742 -2.64907 19.5742 2.15093C9.07422 8.15093 9.07422 37.1484 26.0742 44.6484C39.6742 50.6484 83.4076 18.8168 103.574 2.15093M103.574 2.15093H83.0742M103.574 2.15093V35.6509"
                      stroke="#D3ED05"
                      strokeWidth="2.5"
                    />
                  </svg>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mx-auto">
          <div className="md:size-[400px] size-full text-center">
            <img
              className="size-full object-over"
              src="../assets/buy-crypto/img-3.png"
              alt=""
            />
          </div>

          <button className="bg-[#D3ED05] md:w-[380px] h-[50px] w-full rounded-[18px] text-black border-0 mb-3 font-medium text-sm">
            GET AN INVADER
          </button>
          <p className="text-center text-[#D3ED05] text-base font-archivo font-normal">
            Already have an Invaders Club account
          </p>

          <p className="w-full flex justify-center mt-10">
            <svg
              id="small-3"
              width="49"
              height="86"
              viewBox="0 0 49 86"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                ref={smallRef3}
                d="M47.8463 40.9544C37.013 51.621 17.3463 74.8544 25.3463 82.4544C35.3463 91.9544 47.3486 48.9544 45.8486 40.9544C44.3486 32.9544 41.3486 -6.04563 2.34857 2.45437C-1.31809 9.12062 2.14857 26.1531 45.3486 40.9531"
                stroke="#D3ED05"
                strokeWidth="2.5"
              />
            </svg>
          </p>
        </div>
      </section>

      {/* draw-line animation container */}
      <section
        className="relative mt-18 will-change-transform contain-layout"
        ref={(el) => (refs.current.scope = el)}
      >
        {/* draw-line svg path */}
        <svg
          id="wrap"
          viewBox="0 0 1432 2455"
          height="2455"
          preserveAspectRatio="none"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          style={{ overflow: "visible" }}
          className="w-full absolute top-0 left-0"
        >
          <path
            ref={(el) => (refs.current.path = el)}
            d={childline}
            stroke={strokeData.strokeColor}
            strokeWidth={strokeData.strokeWidth}
          />
          {/* small-3 INSIDE */}
          <g transform="translate(1125, 15)">
            <path
              ref={(el) => (refs.current.wings = el)}
              d={wings}
              stroke={strokeData.strokeColor}
              strokeWidth={strokeData.strokeWidth}
            />
          </g>
          {/* icons to fall in along the path */}
          <circle id="anchor1" cx="160" cy="1090" />
          <circle id="anchor2" cx="210" cy="1090" />
          <circle id="anchor3" cx="185" cy="1040" />
          <circle id="anchor4" cx="320" cy="1110" r="4" fill="red" />
          <circle id="anchor5" cx="340" cy="1430" />
          <circle id="anchor6" cx="180" cy="1570" />
          <circle id="anchor7" cx="370" cy="1590" />
          <circle id="anchorMergePath" cx="280" cy="1695" />
          {/* snow particles */}
          <g id="snowGroup" opacity="0" fill="white">
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
            <circle cx="0" cy="0" r="5.5" />
          </g>
        </svg>

        {/* content-1 */}
        <main
          className="w-full h-[890px] flex justify-start relative"
          ref={(el) => (refs.current.stage1 = el)}
        >
          {/* content */}
          <div
            className="flex flex-col ml-28 mt-25 gap-6 w-1/2"
            ref={(el) => (refs.current.content1 = el)}
          >
            <h6 className="text-[#C5DE05] text-2xl xl:text-3xl font-medium font-archivo">
              Stage 1
            </h6>
            <h2 className="text-white text-3xl xl:text-4xl font-normal font-gothic max-w-[550px]">
              Welcome to SwapSpace Invaders Club!
            </h2>

            <div className="flex flex-col text-[15px] xl:text-base gap-5">
              <p className="text-white font-archivo font-normal">
                We started with deploying a Polygon ERC-721 contract and issued
                genesis tokens. These were limited to 3999, they have a special
                trait animated laser eyes. There were 3 ways to get them.
              </p>
              <p className="text-white font-archivo font-normal">
                After all 3999 genesis tokens are distributed the exchange
                minting will continue, but those tokens won't have any special
                traits, points and benefits from the beginning.
              </p>
            </div>
          </div>

          {/* button-svg */}

          {/* BTN 1 */}
          <div
            ref={(el) => (refs.current.btnWraps[0] = el)}
            className="btn-1 absolute top-0 left-0 flex gap-10"
          >
            <div
              ref={(el) => (refs.current.buttons[0] = el)}
              className="relative w-36 h-10"
            >
              <svg viewBox="0 0 144 40" className="w-full h-full rotate-10">
                {/* BUTTON SHAPE */}
                <path id="btnShape1" fill="#d3ed05" d={buttonShape} />

                <text
                  id="btnText1"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="16"
                  fill="black"
                >
                  btn-1
                </text>
                {/* STAR SHAPE (MORPH TARGET) */}
                <path
                  id="starShape"
                  fill="url(#starGradient)"
                  d={starShape}
                  style={{ visibility: "hidden" }}
                />
                {/* GRADIENT */}
                <defs>
                  <linearGradient
                    id="starGradient"
                    x1="12"
                    y1="0"
                    x2="12"
                    y2="22.32"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="#F0E49A" />
                    <stop offset="1" stopColor="#6FABCE" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            <div
              ref={(el) => (refs.current.buttons[1] = el)}
              className="relative w-[54px] h-10"
            >
              <svg
                viewBox="0 0 54 40"
                className="w-full h-full rotate-9 absolute -right-16"
              >
                {/* BUTTON SHAPE */}
                <path id="btnShape2" fill="#d3ed05" d={smallButtonShape} />

                {/* TEXT */}
                <text
                  id="btnText2"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="14"
                  fill="black"
                >
                  11
                </text>

                {/* TARGET SHAPE (SQUARE) */}
                <path
                  id="squareShape"
                  d={squareShape}
                  fill="url(#squareGradient)"
                  style={{ visibility: "hidden" }}
                />

                {/* GRADIENT */}
                <defs>
                  <linearGradient
                    id="squareGradient"
                    x1="0"
                    y1="0"
                    x2="1"
                    y2="1"
                  >
                    <stop offset="0%" stopColor="#ff00cc" />
                    <stop offset="50%" stopColor="#00e5ff" />
                    <stop offset="100%" stopColor="#00ff88" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>

          {/* BTN 2 */}
          <div
            ref={(el) => (refs.current.btnWraps[1] = el)}
            className="btn-1 absolute top-0 left-0 flex gap-10"
          >
            <div
              ref={(el) => (refs.current.buttons[2] = el)}
              className="relative w-36 h-10"
            >
              <svg viewBox="0 0 144 40" className="w-full h-full -rotate-10">
                {/* BUTTON SHAPE */}
                <path id="btnShape3" fill="#d3ed05" d={buttonShape} />

                <text
                  id="btnText3"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="16"
                  fill="black"
                >
                  btn-2
                </text>

                {/* STAR SHAPE (MORPH TARGET) */}
                <path
                  id="shieldShape"
                  fill="url(#starGradient)"
                  d={shieldShape}
                  style={{ visibility: "hidden" }}
                />

                {/* GRADIENT */}
                <defs>
                  <linearGradient
                    id="shieldGradient"
                    x1="0"
                    y1="0"
                    x2="1"
                    y2="1"
                  >
                    <stop offset="0%" stopColor="#ff0000" />
                    <stop offset="20%" stopColor="#ff7a00" />
                    <stop offset="40%" stopColor="#ffe600" />
                    <stop offset="60%" stopColor="#00ff90" />
                    <stop offset="80%" stopColor="#00c3ff" />
                    <stop offset="100%" stopColor="#a100ff" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            <div
              ref={(el) => (refs.current.buttons[3] = el)}
              className="relative w-[54px] h-10"
            >
              <svg
                viewBox="0 0 54 40"
                className="w-full h-full -rotate-25 absolute -left-6"
              >
                {/* BUTTON SHAPE */}
                <path id="btnShape4" fill="#d3ed05" d={smallButtonShape} />

                {/* TEXT */}
                <text
                  id="btnText4"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="14"
                  fill="black"
                >
                  22
                </text>

                {/* TARGET SHAPE (impeller) */}
                <path
                  id="impellerShape"
                  d={impellerShape}
                  fill="url(#diamondGradient)"
                  style={{ visibility: "hidden" }}
                />

                {/* GRADIENT */}
                <defs>
                  <linearGradient
                    id="impellerGradient"
                    x1="0"
                    y1="0"
                    x2="1"
                    y2="1"
                  >
                    <stop offset="0%" stopColor="#ff00cc" />
                    <stop offset="50%" stopColor="#00e5ff" />
                    <stop offset="100%" stopColor="#00ff88" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>

          {/* BTN 3 */}
          <div
            ref={(el) => (refs.current.btnWraps[2] = el)}
            className="btn-1 absolute top-0 left-0 flex gap-10"
          >
            <div
              ref={(el) => (refs.current.buttons[4] = el)}
              className="relative w-36 h-10"
            >
              <svg viewBox="0 0 144 40" className="w-full h-full rotate-15">
                {/* BUTTON SHAPE */}
                <path id="btnShape5" fill="#d3ed05" d={buttonShape} />

                <text
                  id="btnText5"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="16"
                  fill="black"
                >
                  btn-3
                </text>

                {/* STAR SHAPE (ARROW) */}
                <path
                  id="arrowShape"
                  fill="url(#arrowGradient)"
                  d={arrowShape}
                  style={{ visibility: "hidden" }}
                />

                {/* GRADIENT */}
                <defs>
                  <linearGradient
                    id="arrowGradient"
                    x1="0"
                    y1="0"
                    x2="1"
                    y2="1"
                  >
                    <stop offset="0%" stopColor="#ff0000" />
                    <stop offset="20%" stopColor="#ff7a00" />
                    <stop offset="40%" stopColor="#ffe600" />
                    <stop offset="60%" stopColor="#00ff90" />
                    <stop offset="80%" stopColor="#00c3ff" />
                    <stop offset="100%" stopColor="#a100ff" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            <div
              ref={(el) => (refs.current.buttons[5] = el)}
              className="relative w-[54px] h-10"
            >
              <svg
                viewBox="0 0 54 40"
                className="w-full h-full rotate-19 absolute -right-16"
              >
                {/* BUTTON SHAPE */}
                <path id="btnShape6" fill="#d3ed05" d={smallButtonShape} />

                {/* TEXT */}
                <text
                  id="btnText6"
                  x="50%"
                  y="50%"
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="14"
                  fill="black"
                >
                  33
                </text>

                {/* TARGET SHAPE (B) */}
                <path
                  id="bShape"
                  d={bShape}
                  fill="url(#bGradient)"
                  style={{ visibility: "hidden" }}
                />

                {/* GRADIENT */}
                <defs>
                  <linearGradient id="bGradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#ff00cc" />
                    <stop offset="50%" stopColor="#00e5ff" />
                    <stop offset="100%" stopColor="#00ff88" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>

          {/* reveal svg */}
          {/* starShape */}
          <div
            id="iconStar1"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path id="shape1" d={starShape} fill="#F0E49A" />

              {/* GRADIENT */}
              <defs>
                <linearGradient id="shieldGradient" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#ff0000" />
                  <stop offset="20%" stopColor="#ff7a00" />
                  <stop offset="40%" stopColor="#ffe600" />
                  <stop offset="60%" stopColor="#00ff90" />
                  <stop offset="80%" stopColor="#00c3ff" />
                  <stop offset="100%" stopColor="#a100ff" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          {/* squareShape */}
          <div
            id="iconStar2"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 64 64" width="24" height="24">
              <path id="squareShape1" d={squareShape} fill="#F0E49A" />
              {/* <path
                id="arrowShape1"
                fill="url(#arrowGradient1)"
                d={arrowShape}
                style={{ visibility: "hidden" }}
              /> */}
              <circle
                id="mergeAnchor"
                cx="32"
                cy="32"
                // r="16"
                // fill="red"
                // stroke="white"
                // strokeWidth="1"
              />

              {/* GRADIENT */}
              <defs>
                <linearGradient id="arrowGradient1" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#ff0000" />
                  <stop offset="20%" stopColor="#ff7a00" />
                  <stop offset="40%" stopColor="#ffe600" />
                  <stop offset="60%" stopColor="#00ff90" />
                  <stop offset="80%" stopColor="#00c3ff" />
                  <stop offset="100%" stopColor="#a100ff" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          {/* shieldShape */}
          <div
            id="iconStar3"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path id="shape3" d={shieldShape} fill="#F0E49A" />
            </svg>
          </div>
          {/* impellerShape */}
          <div
            id="iconStar4"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 30 30" width="60" height="60">
              <path id="shape4" d={starShape} fill="#F0E49A" />
              <path
                id="arrowShape1"
                fill="url(#arrowGradient1)"
                d={arrowShape}
                style={{ visibility: "hidden" }}
              />
            </svg>
          </div>
          {/* bShape */}
          <div
            id="iconStar5"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path d={bShape} fill="#F0E49A" />
            </svg>
          </div>
          {/* mshape */}
          <div
            id="iconStar6"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 40 40" width="24" height="24">
              <g transform="translate(2,2)">
                <path d={mShape} fill="#F0E49A" />
              </g>
            </svg>
          </div>
          {/* heartShape */}
          <div
            id="iconStar7"
            className="absolute top-0 left-0 pointer-events-none"
          >
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path d={heartShape} fill="#F0E49A" />
            </svg>
          </div>
        </main>

        {/* content-2 */}
        <main
          className="w-full h-[520px] flex justify-center relative"
          ref={(el) => (refs.current.stage2 = el)}
        >
          <div
            className="w-1/2 flex flex-col gap-6 ml-130"
            ref={(el) => (refs.current.content2 = el)}
          >
            <h6 className="text-[#C5DE05] text-3xl font-medium font-archivo">
              Stage 2
            </h6>
            <h2 className="text-white text-4xl font-normal font-gothic max-w-[550px]">
              Reveal & customize
            </h2>

            <div className="flex flex-col gap-5">
              <p className="text-white text-base font-archivo font-normal">
                We started with deploying a Polygon ERC-721 contract and issued
                genesis tokens. These were limited to 3999, they have a special
                trait animated laser eyes. There were 3 ways to get them.
              </p>

              <button className="w-20 h-12 rounded-[12px] bg-[#c5de05] text-lg font-archivo font-normal text-black">
                share
              </button>
            </div>
          </div>
        </main>

        {/* content-3 */}
        <main
          className="w-full h-[1045px] flex justify-end relative"
          ref={(el) => (refs.current.stage3 = el)}
        >
          <div
            className="w-[60%] flex flex-col gap-6 -ml-30 relative overflow-hidden"
            ref={(el) => (refs.current.content3 = el)}
          >
            <h6 className="text-[#C5DE05] text-2xl xl:text-3xl font-medium font-archivo">
              Stage 3
            </h6>
            <h2 className="text-white text-3xl xl:text-4xl font-normal font-gothic max-w-[550px]">
              Metaverse of loyalty
            </h2>

            <p className="text-white text-[15px] xl:text-base font-archivo font-normal">
              Log in with your Invader and exchange your crypto on SwapSpace.
              With each swap you receive Diamonds that would help to upgrade
              your Invader. The higher the Invader's level, the more cashback
              from each swap you'll get.
            </p>

            <div className="w-[90%] overflow-x-auto">
              <div className="inline-block min-w-max">
                <div className="flex flex-col gap-5">
                  {/* row-1 */}
                  <div className="grid grid-flow-col auto-cols-max gap-4">
                    <p className="w-26 h-30 flex items-center justify-center rounded-[12px] border border-[#d3ed05] bg-[#4e5800] text-[#d3ed05] text-lg font-archivo font-medium">
                      Level
                    </p>
                    {levels.map((items) => (
                      <div
                        className="w-26 h-30 flex items-center justify-center text-sm text-white font-archivo font-medium rounded-[12px] border border-[#d3ed05] bg-[#4e5800]"
                        key={items.id}
                      >
                        {items.label}
                      </div>
                    ))}
                  </div>

                  {/* row-2 */}
                  <div className="grid grid-flow-col auto-cols-max gap-4">
                    <p className="w-26 h-30 flex items-center justify-center rounded-[12px] border border-[#d3ed05] bg-[#4e5800] text-[#d3ed05] text-xs px-4 text-center font-archivo font-medium">
                      Subscription cost per level
                    </p>
                    {costData.map((items) => (
                      <div
                        className="w-26 h-30 flex flex-col items-center gap-1.5 justify-center text-sm text-white font-archivo font-medium rounded-[12px] border border-[#d3ed05] bg-[#4e5800]"
                        key={items.id}
                      >
                        <p>
                          <svg
                            width="22"
                            height="22"
                            viewBox="0 0 22 22"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <g clipPath="url(#clip0_1_35887)">
                              <path
                                d="M19.7823 0C20.1042 0.176657 19.9831 0.392189 20.0338 0.656929C20.1594 1.31583 20.4508 2.01508 21.1243 2.26751C21.4635 2.39496 22.0178 2.26358 21.9961 2.77288C21.9769 3.23101 21.4502 3.10897 21.1243 3.2315C20.4666 3.47804 20.1692 4.15908 20.0417 4.80075C19.9841 5.0901 20.1033 5.52313 19.6115 5.50246C19.164 5.48376 19.2831 5.07533 19.2285 4.80075C19.1014 4.15908 18.8036 3.47804 18.1459 3.2315C17.82 3.10947 17.2933 3.2315 17.2741 2.77288C17.2524 2.26358 17.8067 2.39447 18.1459 2.26751C18.8194 2.01508 19.1103 1.31583 19.2363 0.656929C19.287 0.392189 19.1654 0.176657 19.4879 0H19.7828L19.7823 0ZM20.3716 2.70153C20.1559 2.71186 19.6907 1.94422 19.611 1.96439C19.416 2.23307 19.2053 2.56276 18.8986 2.70153V2.79798C19.1142 2.78764 19.5795 3.55529 19.6592 3.53512C19.8542 3.26644 20.0649 2.93675 20.3716 2.79798V2.70153Z"
                                fill="white"
                              />
                              <path
                                d="M7.11311 3.9277H17.7968C17.8283 3.9277 17.9607 4.03645 17.9913 4.0768L20.4281 8.22456C20.4473 8.37513 20.3572 8.46371 20.2883 8.57836C19.8398 9.31895 19.1324 10.0408 18.6564 10.7804C18.551 10.837 18.1212 10.4739 18.0243 10.3774L19.2456 8.64086H14.432L11.2887 19.4425L16.1998 12.7871C16.3524 12.6897 16.7251 13.1252 16.8876 13.1818L10.502 21.8724C10.3888 22.0004 10.2175 22.027 10.0575 21.9733L3.40567 13.0091L3.2821 12.9613C3.08667 13.2802 3.27177 14.0385 2.85283 14.13C2.25666 14.2604 2.36989 13.5823 2.27488 13.2064C2.15968 12.7512 1.83083 12.3325 1.36857 12.1971C1.16624 12.1381 0.891047 12.2242 0.798004 11.9324C0.558258 11.182 1.72794 11.5446 1.89926 10.9817L0.0467677 8.46272L0 8.13647L2.42404 4.0768C2.45506 4.03645 2.58748 3.9277 2.6185 3.9277H5.44277C5.22469 3.39871 4.17315 3.71512 4.32281 3.03063C4.39468 2.70241 4.694 2.78951 4.90568 2.728C5.35268 2.59711 5.6707 2.19311 5.80165 1.75762C5.90651 1.40824 5.78097 0.801992 6.25456 0.781817C6.77639 0.759673 6.65036 1.39151 6.75473 1.75762C6.87878 2.19409 7.20419 2.5976 7.6507 2.728C7.86238 2.79 8.16169 2.70241 8.23357 3.03063C8.38323 3.71512 7.33169 3.39871 7.11361 3.9277H7.11311ZM6.258 2.6532L5.83956 3.16005L6.29788 3.63146L6.71633 3.12462L6.258 2.6532ZM5.83562 4.71355H3.62523L6.3028 7.70935L10.06 4.71355H6.71977C6.65233 5.02159 6.73897 5.48366 6.30133 5.50236C5.75636 5.52549 5.93014 4.77309 5.83562 4.71355ZM16.7896 4.71355H10.3549L14.111 7.70885L16.7891 4.71355H16.7896ZM5.3448 7.85549L2.81492 5.0088L1.12045 7.85549H5.3448ZM19.3436 7.85549L17.5999 5.0088L15.0213 7.85549H19.3436ZM7.4075 7.85549H13.0073L10.1855 5.64359L7.408 7.85549H7.4075ZM5.98331 8.64135H1.16919L2.25076 10.1634C2.46638 9.9808 2.21383 9.56942 2.59142 9.44886C3.22155 9.24809 3.11423 10.0207 3.2186 10.3981C3.3402 10.8375 3.66461 11.2381 4.11358 11.3695C4.37154 11.4447 4.72846 11.3552 4.70926 11.8074C4.69006 12.2596 4.21155 12.1179 3.93291 12.2645C3.88812 12.2882 3.85316 12.2503 3.87138 12.3477L9.17532 19.4927L5.98281 8.64184L5.98331 8.64135ZM13.5966 8.64135H6.81823L10.2318 20.131L13.5971 8.64135H13.5966ZM2.78932 12.3231L3.17971 11.7656L2.72139 11.2942L2.30294 11.801L2.6884 12.2926L2.78981 12.3231H2.78932Z"
                                fill="white"
                              />
                              <path
                                d="M16.8382 11.977C16.7969 11.9164 17.3271 11.2612 17.4019 11.1445L18.0138 11.6157L17.4438 12.3664L16.8377 11.977H16.8382Z"
                                fill="white"
                              />
                            </g>
                            <defs>
                              <clipPath id="clip0_1_35887">
                                <rect width="22" height="22" fill="white" />
                              </clipPath>
                            </defs>
                          </svg>
                        </p>
                        <p>{items.cost}</p>
                      </div>
                    ))}
                  </div>

                  {/* row-3 */}
                  <div className="grid grid-flow-col auto-cols-max gap-4">
                    <p className="w-26 h-30 flex flex-col items-center justify-center rounded-[12px] border border-[#d3ed05] bg-[#4e5800] text-[#d3ed05] text-xs px-2.5 text-center font-archivo font-medium">
                      Cashback
                      <span>(% of revenue share)</span>
                    </p>
                    {CaseBackData.map((items) => (
                      <div
                        className="w-26 h-30 flex items-center justify-center text-sm text-white font-archivo font-medium rounded-[12px] border border-[#d3ed05] bg-[#4e5800]"
                        key={items.id}
                      >
                        <p>{items.caseback}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* bg-white circle */}

          <div
            ref={(el) => (refs.current.bg[0] = el)}
            className="size-14.5 bg-white rounded-full absolute bottom-16 left-9 -z-1"
          ></div>
          <div
            ref={(el) => (refs.current.bg[1] = el)}
            className="size-14 bg-white rounded-full absolute bottom-16 left-9 -z-1"
          ></div>
          <div
            ref={(el) => (refs.current.bg[2] = el)}
            className="size-12 bg-white rounded-full absolute bottom-16 left-9 -z-1"
          ></div>
        </main>
      </section>

      <div className="particle-container absolute inset-0 pointer-events-none z-30" />

      <section
        ref={revealSection}
        className="w-full grid md:grid-cols-2 grid-cols-1 lg:gap-12 gap-7 pt-[30px]"
      >
        {/* <div>
          <div>
            <Accordion
              type="single"
              collapsible
              className="w-full flex flex-col gap-4" // Added gap between items
              defaultValue="item-1"
            >
              {faqData.map((faq) => (
                <AccordionItem
                  key={faq.id}
                  value={faq.id}
                  className="bg-[#1C1C1C] border! border-[#868E96]! rounded-lg px-4"
                >
                  <AccordionTrigger className="flex hover:underline-offset-0! ! w-full items-center justify-between text-white font-semibold font-archivo text-md">
                    <span className="line-clamp-1 font-archivo font-normal text-left">
                      {faq.question}
                    </span>

                    Custom Arrow
                    <span className="size-5 shrink-0">
                      <img
                        src="/../assets/hero-banner/arrow-down.svg"
                        alt="arrow"
                        className="size-full transition-transform duration-300 accordion-arrow"
                      />
                    </span>
                  </AccordionTrigger>

                  <AccordionContent className="flex flex-col gap-2 text-balance">
                    <p className="text-sm text-white font-archivo font-normal">
                      {faq.answer}
                    </p>
                    <p className="text-[#D3ED05] text-sm font-archivo font-normal cursor-pointer">
                      {faq.linkText}
                    </p>
                    <p className="text-sm text-white font-archivo font-normal">
                      Remember to always do your own research, though. Have fun!
                    </p>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div> */}
        <div className="mx-auto">
          <div className="text-center">
            {/* <img
              className="w-full"
              src="../assets/buy-crypto/img-2.png"
              alt=""
            /> */}
            <p>image</p>
          </div>
        </div>
      </section>
    </section>
  );
};

export default InvadersClub;
